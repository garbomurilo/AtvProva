﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void maskedTextBox3_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void lblPeso_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
            txtboxImc.Text = imc.ToString();

            if (imc < 18.5)
            {
                MessageBox.Show("Sua classificação é Magreza");
                MessageBox.Show("Sua classificação de obesidade é 0");
            }
            else if (imc <= 24.9)
            {
                MessageBox.Show("Sua classificação é Normal");
                MessageBox.Show("Sua classificação de obesidade é 0");
            }
            else if (imc <= 29.9)
            {
                MessageBox.Show("Sua classificação é Sobrepeso");
                MessageBox.Show("Sua classificação de obesidade é I");
            }
            else if (imc <= 39.9)
            {
                MessageBox.Show("Sua classificação é Obesidade");
                MessageBox.Show("Sua classificação de obesidade é I");
            }
            else 
           {

                MessageBox.Show("Sua classificação é Obesidade Grave");
                MessageBox.Show("Sua classificação de obesidade é III");
            }
        }


        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            txtboxImc.Clear();
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(mskbxAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Altura Inválida");
                mskbxAltura.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out peso) || peso <= 0)
            {
                MessageBox.Show("Peso Inválido");
                mskbxPeso.Focus ();
            }
        }
    }
}
